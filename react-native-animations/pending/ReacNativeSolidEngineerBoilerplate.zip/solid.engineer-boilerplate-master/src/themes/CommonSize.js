const { Dimensions } = require('react-native');

const { width, height } = Dimensions.get('screen');

const CommonHeight = {
  // Add size as your willing following this partern : 'height * {percentage of screen}'
  p1: height * 0.01,
  p2: height * 0.02,
  p3: height * 0.03,
  p7: height * 0.07,
};

const CommonWidth = {
  // Add size as your willing following this partern : 'height * {percentage of screen}'
  p1: width * 0.01,
  p10: width * 0.1,
  p20: width * 0.2,
  p25: width * 0.25,
  p30: width * 0.3,
  horizontalSpacing: 30,
};

const CommonSize = {
  CommonHeight,
  CommonWidth,
};

export default CommonSize;
