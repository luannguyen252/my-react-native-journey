
import { NativeModules } from 'react-native';

const { RNDownloadButton } = NativeModules;

export default RNDownloadButton;
