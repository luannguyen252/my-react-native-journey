# Pietile Native Kit Example

As this is workspace project all dependencies are installed by calling `yarn` in outside directory.
In every other aspect this is a regular React Native app. Most common commands are:

- `react-native run-ios` to run on iOS simulator
- `react-native run-android` to run on attached Android instance

And don't forget to run `pod install` in `ios` directory before first run or after updates.
