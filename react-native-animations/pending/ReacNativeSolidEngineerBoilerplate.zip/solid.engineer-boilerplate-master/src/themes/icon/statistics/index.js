import * as React from 'react';
import Svg, { Path, Rect } from 'react-native-svg';

const Statistics = ({ colour, width, height }) => (
  <Svg viewBox="0 0 145 145" width={width} height={height}>
    <Path fill={colour} class="cls-1" d="M144,576" transform="translate(-143.5 -431.5)" />
    <Rect fill={colour} class="cls-1" x="0.5" y="72.5" width="36" height="72" rx="9.34" />
    <Rect fill={colour} class="cls-1" x="54.5" y="36.5" width="36" height="108" rx="8.88" />
    <Rect fill={colour} class="cls-1" x="108.5" y="0.5" width="36" height="144" rx="8.85" />
  </Svg>
);

export default Statistics;
