
#if __has_include("RCTBridgeModule.h")
#import "RCTViewManager.h"
#else
#import <React/RCTViewManager.h>
#endif

#import "FFCircularProgressView.h"

@interface RNDownloadButton : RCTViewManager

@end
  
