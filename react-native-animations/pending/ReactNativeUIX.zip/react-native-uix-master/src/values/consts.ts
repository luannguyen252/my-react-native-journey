export const LABEL_EDIT = "Edit";
export const LABEL_CANCEL = "Cancel";
export const PLACEHOLDER_SEARCH = "Search";
