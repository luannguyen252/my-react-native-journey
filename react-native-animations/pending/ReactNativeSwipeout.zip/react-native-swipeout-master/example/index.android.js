import SwipeoutExample from './SwipeoutExample';
import {
  AppRegistry,
} from 'react-native';

AppRegistry.registerComponent('swipeoutExample', () => SwipeoutExample);
