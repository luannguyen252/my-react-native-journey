# react-native-offscreen-toolbar: example application

Example usage of the library, using a simple `FlatList` for the scrollable content and `ToolbarAndroid` for the toolbar.

Created via [create-react-native-app](https://github.com/react-community/create-react-native-app)

![simple list demo](https://lopespm.github.io/files/rn-offscreen-toolbar/simplelist_demo.gif)


