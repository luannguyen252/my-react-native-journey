import Tabbar from './src/Tabbar';

export default Tabbar;
