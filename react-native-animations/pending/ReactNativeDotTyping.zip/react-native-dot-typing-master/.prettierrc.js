module.exports = {
  printWidth: 120,
  tabWidth: 2,
  singleQuote: false,
  trailingComma: "all",
  quoteProps: "preserve",
  semi: true,
};
