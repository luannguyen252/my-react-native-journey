# STEPS TO RUN THE APP:
1. Run `npm i` in the root of the project.
2. Add shutterstock client id and client secret in `./src/api/imageSearch.js` file
3. Run `react-native run-ios` to run the app on iOS platform and `react-native run-android` to run on Android.
