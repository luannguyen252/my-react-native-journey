export default {
    Alice: 'Alice-Regular',
    Quattrocento: 'Quattrocento-Regular',
    Walk: 'Walk with me now',
    Optimus: 'OptimusPrinceps',
    OptimusBold: 'OptimusPrincepsSemiBold',
    KBWriter: 'KBYoureJustMyType',
    KBWriterThin: 'KBYoureJustMyTypeThin',
}
