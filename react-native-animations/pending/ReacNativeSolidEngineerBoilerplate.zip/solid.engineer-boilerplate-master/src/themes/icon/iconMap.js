import React from 'react';
import generalIcon from 'themes/GeneralIcon';
import Back from './Back';
import Home from './Home';
import Market from './Market';
import Notification from './Notification';
import Statistics from './statistics';

export const map = {
  [generalIcon.BACK]: Back,
  [generalIcon.HOME]: Home,
  [generalIcon.MARKET]: Market,
  [generalIcon.STATISTICS]: Statistics,
  [generalIcon.NOTIFICATION]: Notification,
};

export const getIconComponent = (type, props) =>
  map[type] ? React.createElement(map[type], props) : React.createElement(Back, props);
