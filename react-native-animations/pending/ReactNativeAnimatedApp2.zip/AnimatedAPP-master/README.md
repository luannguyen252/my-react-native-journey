# Animated APP

### App built with React Native to test some animations

# <img align="center" width="318" height="640" src="./animatedapp_v2.gif">

### https://undraw.co/illustrations
