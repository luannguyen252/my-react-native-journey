# Stellar Wallet
Lightweight app to send and receive lumens over the Stellar network.

## Demo
You can try this app out using [Expo](https://exp.host/@mastermo/stellar-wallet).

## Screenshot
![Home Screen](https://i.imgur.com/yOQ6dzB.jpg)

## Todo
- [ ] Manage Wallets from both Testnet and Public Network