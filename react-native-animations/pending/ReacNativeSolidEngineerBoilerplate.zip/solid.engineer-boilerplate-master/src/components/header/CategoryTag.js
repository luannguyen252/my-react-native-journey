import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Colors from 'themes/CommonColors';
import CommonSize from 'themes/CommonSize';

const styles = StyleSheet.create({
  categoryTagContainer: {
    paddingTop: CommonSize.CommonHeight.p7,
    alignSelf: 'flex-start',
    paddingBottom: 10,
    paddingHorizontal: 18,
    backgroundColor: Colors.categoryGray,
    alignItems: 'center',
  },
  categoryTagContainerInActive: {
    paddingTop: CommonSize.CommonHeight.p7,
    alignSelf: 'flex-start',
    paddingBottom: 10,
    paddingHorizontal: 18,
    backgroundColor: Colors.transparent,
    alignItems: 'center',
  },
  categoryTag: {
    fontSize: 15,
    fontWeight: '700',
  },
  categoryTagInActive: {
    fontSize: 15,
    color: Colors.inActiveCategoryGray,
    fontWeight: '700',
  },
});

const CategoryTag = ({ tagContent, isActive }) => (
  <View style={isActive ? styles.categoryTagContainer : styles.categoryTagContainerInActive}>
    <Text style={isActive ? styles.categoryTag : styles.categoryTagInActive}>{tagContent}</Text>
  </View>
);

export default CategoryTag;
