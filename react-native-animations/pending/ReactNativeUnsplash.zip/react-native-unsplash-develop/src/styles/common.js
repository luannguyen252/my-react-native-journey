export const COLORS = {
  WHITE: 'rgba(245, 246, 250, 1)',
  TRANSPARENT_WHITE: 'rgba(245, 246, 250, 0.75)',
};