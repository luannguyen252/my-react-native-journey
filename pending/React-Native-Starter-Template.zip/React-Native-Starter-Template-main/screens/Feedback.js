

import React from 'react'
import {
    View,
    Text
} from "react-native";

import Header from '../components/Header';

const Feedback = () => {
    return (
        <Header text="Header" />
    )
}

export default Feedback
