
#import "RCTUIManager.h"
#import <UIKit/UIKit.h>

#import <SexyTooltip/SexyTooltip.h>

@interface RNTooltips : NSObject <RCTBridgeModule>

@end
  
