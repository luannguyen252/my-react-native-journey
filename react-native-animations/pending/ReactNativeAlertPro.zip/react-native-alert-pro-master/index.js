import AlertPro from "./src";

export default AlertPro;
