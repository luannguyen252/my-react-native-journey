/**
 * react-native-easy-toast examples
 * https://github.com/crazycodeboy/react-native-easy-toast
 * Email:crazycodeboy@gmail.com
 * Blog:http://jiapenghui.com
 * @flow
 */

import {
    AppRegistry,
} from 'react-native';

import index from './index.js'

AppRegistry.registerComponent('examples', () => index);
