import Slider from './Slider';
import SliderButtonIcon from './SliderButtonIcon';

export { Slider, SliderButtonIcon };

export default Slider;
