export { default as Home } from "./Home";
export { default as Deposit } from "./Deposit";
export { default as New } from "./New";
export { default as Payment } from "./Payment";
export { default as Send } from "./Send";
export { default as Settings } from "./Settings";
