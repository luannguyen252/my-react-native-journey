import SwipeView from './src/swipeView';

export default SwipeView;
