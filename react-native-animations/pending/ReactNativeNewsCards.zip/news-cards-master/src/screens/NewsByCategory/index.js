import NewsByCategory from './NewsByCategory'
export default NewsByCategory 