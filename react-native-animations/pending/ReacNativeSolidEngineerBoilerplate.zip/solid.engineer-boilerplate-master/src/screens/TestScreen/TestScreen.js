import HeaderComponent from 'components/header';
import React, { Component } from 'react';
import { View } from 'react-native';
import styles from './styles';

class TestScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { increment } = this.props;
    return (
      <View style={styles.flexOne}>
        <HeaderComponent />
      </View>
    );
  }
}

export default TestScreen;
