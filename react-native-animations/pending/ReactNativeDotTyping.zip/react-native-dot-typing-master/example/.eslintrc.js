module.exports = {
  extends: '../.eslintrc',
};
