import Header from 'components/header/styles';
import React, { Component } from 'react';
import { SafeAreaView, View } from 'react-native';
import styles from './styles';

function CustomScreen(WrappedComponent) {
  class Screen extends Component {
    constructor(props) {
      super(props);
      this.state = {};
    }

    render() {
      return (
        <>
          <SafeAreaView style={styles.statusBar} />
          <Header />
          <View style={{ flex: 1 }}>
            <WrappedComponent {...this.props} />
          </View>
        </>
      );
    }
  }

  return Screen;
}
export default CustomScreen;
