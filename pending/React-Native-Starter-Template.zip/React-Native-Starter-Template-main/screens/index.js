

import Home from './Home';
import Settings from './Settings';
import Feedback from './Feedback';

export {
    Home,
    Settings,
    Feedback
}