const prettierConfig = require('@wkovacs64/prettier-config');

module.exports = {
  ...prettierConfig,
};
