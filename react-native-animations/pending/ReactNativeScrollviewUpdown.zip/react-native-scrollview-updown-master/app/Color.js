import React , { Component } from 'react'
import {
  Dimensions,
} from 'react-native'

export var descInfo = {
 wh   : '#fff'   ,  // white 白色
 bk   : '#282832' , // black 黑色
 og   : '#ff8000',  // range 桔色
 gn   : '#00a0a0'  ,// green 绿色
 gy   : '#8c8c96' , // gray  灰色 文本
 gyll : '#f4f4f4'  ,// gray lighter  浅灰 背景
 width : Dimensions.get('window').width,
 height : Dimensions.get('window').height
}

