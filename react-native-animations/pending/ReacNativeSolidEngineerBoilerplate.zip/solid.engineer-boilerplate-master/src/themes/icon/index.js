import Colors from 'themes/CommonColors';

import { getIconComponent } from './iconMap';

const SVGIcon = ({ type, colour = Colors.dark1, stroke, size = 24, disabled = false }) => {
  const iconColour = disabled ? Colors.greyLogo : colour;

  const iconProps = {
    colour: iconColour,
    fill: iconColour,
    stroke,
    width: size,
    height: size,
  };

  return getIconComponent(type, iconProps);
};

export default SVGIcon;
