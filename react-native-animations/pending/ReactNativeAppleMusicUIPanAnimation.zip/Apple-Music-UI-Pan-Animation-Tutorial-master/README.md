# Apple-Music-UI-Pan-Animation-Tutorial
Learn How to Create the Now playing Toolbar Animation of Apple Music in React Native

![Alt Text](https://media.giphy.com/media/m8yQCIICcSiWj09bWW/giphy.gif)


## YouTube Tutorial Video 
* ###  [Apple Music Pan Animation Tutorial](https://www.youtube.com/watch?v=yQK2oaIN0yA&list=PLy9JCsy2u97kI4B4NN2MJKy8gokeeGJd-) 

## Installation Instructions 

```js
 $ git clone https://github.com/nathvarun/Apple-Music-UI-Pan-Animation-Tutorial
 $ cd /Apple-Music-UI-Pan-Animation-Tutorial
 $ npm install 
```
