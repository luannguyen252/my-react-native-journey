#!/usr/bin/env bash
set -e
npm install -g file-directives@1.4.6 typescript@2.7.1 tslint@5.8.0
