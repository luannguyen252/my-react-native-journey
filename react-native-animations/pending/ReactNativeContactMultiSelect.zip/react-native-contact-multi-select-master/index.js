import Contacts from './Contacts'
export default Contacts
module.exports = Contacts
