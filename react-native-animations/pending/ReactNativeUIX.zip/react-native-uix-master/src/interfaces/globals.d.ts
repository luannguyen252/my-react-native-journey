declare type HTMLCollection = {};
declare type Node = {};
