                        //  BİSMİLLAHİRRAHMANİRRAHİM



import allImages from './images';
import icons from './icons';
import {COLORS, SIZES, FONTS} from './theme';
import config from './firebase_config';

export {allImages, icons, COLORS, SIZES, FONTS, config};

