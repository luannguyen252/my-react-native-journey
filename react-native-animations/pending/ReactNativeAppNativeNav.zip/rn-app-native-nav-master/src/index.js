import { start } from './App';

start();
