import Camera from './Camera';

module.exports = {
  Camera,
};
