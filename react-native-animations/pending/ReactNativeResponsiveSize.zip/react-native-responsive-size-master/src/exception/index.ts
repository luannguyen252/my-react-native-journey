function Exception(name: string, message: string) {
  return name + ': "' + message + '"';
}

export default Exception;
