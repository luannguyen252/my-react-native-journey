module.exports = {
  extends: '@react-native-community',
};
