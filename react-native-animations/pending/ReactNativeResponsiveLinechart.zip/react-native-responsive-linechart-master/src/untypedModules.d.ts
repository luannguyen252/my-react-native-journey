declare module 'paths-js/bezier'
declare module 'paths-js/polygon'
declare module '@yr/monotone-cubic-spline'
declare module 'react-native-gesture-handler'
