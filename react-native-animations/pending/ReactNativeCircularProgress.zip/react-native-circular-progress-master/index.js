import CircularProgress from './src/CircularProgress';
import AnimatedCircularProgress from './src/AnimatedCircularProgress';

exports.CircularProgress = CircularProgress;
exports.AnimatedCircularProgress = AnimatedCircularProgress;
