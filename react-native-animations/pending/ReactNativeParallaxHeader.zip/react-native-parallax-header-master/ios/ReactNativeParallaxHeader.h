#import <React/RCTBridgeModule.h>

@interface ReactNativeParallaxHeader : NSObject <RCTBridgeModule>

@end
