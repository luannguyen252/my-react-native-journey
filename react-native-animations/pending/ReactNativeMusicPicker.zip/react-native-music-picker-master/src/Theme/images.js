const images = {
  iconAdd: require('../Resources/Images/icon_add.png'),
  iconSong: require('../Resources/Images/icon_song.png'),
  iconTick: require('../Resources/Images/icon_tick.png'),
};

export default images;
