export interface IHeaderActionsMoreOptions {
  label: string;
  onPress?: () => void;
  isCancel?: boolean;
  isDestructive?: boolean;
}
