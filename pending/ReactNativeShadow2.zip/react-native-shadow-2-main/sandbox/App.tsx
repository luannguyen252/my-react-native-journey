// Still haven't found a way to use src/App automatically without this.
import { App } from './src/App';
export default App;