
# reanimated-fab-app

Reanimated floating action button - the app.

I may also publish a npm package for it.

[demo](https://i.imgur.com/h9HdrKl.mp4)

# usage

This demo uses Reanimated v2 alpha 4, react-native-gesture-handler and react-navigation 5 on React native v63.

Reanimated package has been configured for android only. if you wanna test on ios please follow the [insruction for installing it on IOS](https://docs.swmansion.com/react-native-reanimated/docs/next/installation#ios).
