import React from 'react';
import { View, Text } from 'react-native';

import styles from './styles';

const TabTwo = () => {
  return (
    <View style={styles.wrapper}>
      <Text>Tab Two</Text>
    </View>
  );
};

export default TabTwo;
