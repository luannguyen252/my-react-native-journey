import Article from './Article'
export default Article 