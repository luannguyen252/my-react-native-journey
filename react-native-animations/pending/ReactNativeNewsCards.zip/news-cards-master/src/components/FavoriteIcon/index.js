import FavoriteIcon from './FavoriteIcon'
export default FavoriteIcon 