# react-native-navigation

React-Native navigation example, using React Navigation 5.0.

Using Drawer navigation, Material Bottom Tab Navigator and [react-native-vector-icons](https://github.com/oblador/react-native-vector-icons)

Official documention : https://reactnavigation.org/
