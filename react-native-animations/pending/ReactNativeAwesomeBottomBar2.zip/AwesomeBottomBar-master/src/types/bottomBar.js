// @flow

export const BOTTOM_BAR_ITEM_ID = {
  HOME: 'HOME',
  SEARCH: 'SEARCH',
  POST: 'POST',
  LIKE: 'LIKE',
  PROFILE: 'PROFILE',
};
