module.exports = {
  jsxBracketSameLine: true,
  singleQuote: false,
  trailingComma: "all",
};
