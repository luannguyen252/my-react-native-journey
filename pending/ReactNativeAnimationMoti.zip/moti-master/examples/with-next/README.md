# Dripsy + [Next.js Example](https://www.nextjs.org/)

To run this example, clone the root repository.

```sh
git clone https://github.com/nandorojo/dripsy
cd dripsy
```

Link & install dependencies

```sh
yarn
yarn link
cd next-example
yarn
yarn link dripsy
```

Run it

```sh
yarn next
```
