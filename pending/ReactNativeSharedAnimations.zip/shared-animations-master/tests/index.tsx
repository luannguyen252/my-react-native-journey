import * as React from 'react'

export class Cows {
	private ox = 10
	getX = () => this.ox
	setX = (newVal: number) => {
		this.ox = newVal
	}
}

// export const Tester = () => <View

interface Test {
	str: string
}

export let x = new C()
export let y = { ...{ some: 'value' } }
