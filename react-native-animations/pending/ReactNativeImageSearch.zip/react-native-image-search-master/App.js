import React, {Component} from 'react';
import MainScreen from './src/Screens/MainScreen'

export default class App extends Component {
  render() {
    return (
      <MainScreen />
    );
  }
}
