export const colors = {
  PRIMARY: '#55ACEE',
  SECONDARY: '#444B52',
  WHITE: '#FFFFFF',
  LIGHT_GRAY: '#CAD0D6'
};
