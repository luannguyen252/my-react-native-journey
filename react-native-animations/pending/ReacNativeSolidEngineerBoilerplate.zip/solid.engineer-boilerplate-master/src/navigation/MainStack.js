import { createStackNavigator } from '@react-navigation/stack';
import React, { Component } from 'react';
import ROUTES from 'utils/ConstRoute';
import TestScreen from 'screens/TestScreen';
import BottomTabStack from './BottomTabStack';

const Stack = createStackNavigator();

export default class MainStack extends Component {
  componentDidMount() {}

  render() {
    return (
      <Stack.Navigator initialRouteName={ROUTES.BOTTOM_TAB} headerMode="none" mode="card">
        <Stack.Screen name={ROUTES.TEST_SCREEN} component={TestScreen} />
        <Stack.Screen name={ROUTES.BOTTOM_TAB} component={BottomTabStack} />
      </Stack.Navigator>
    );
  }
}
