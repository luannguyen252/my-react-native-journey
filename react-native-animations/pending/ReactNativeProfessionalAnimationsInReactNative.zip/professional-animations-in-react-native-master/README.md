# Performant-Animations-in-React-Native
In this series we create real world high performant animations in react native
