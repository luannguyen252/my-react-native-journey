const prettier = require('./.prettierrc.js');

module.exports = {
  parser: 'babel-eslint',
  env: {
    browser: true,
    es6: true,
  },
  extends: [
    'plugin:react/recommended',
    '@react-native-community',
    'airbnb',
    'prettier',
    'prettier/react',
    // '@paralect/eslint-config',
    'plugin:react-hooks/recommended',
  ],
  globals: {
    __DEV__: true,
    Atomics: 'readonly',
    SharedArrayBuffer: 'readonly',
  },
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
      modules: true,
    },
    ecmaVersion: 2018,
    sourceType: 'module',
  },
  plugins: ['react', 'react-native', 'prettier', 'no-autofix'],
  settings: {
    'import/resolver': {
      'babel-module': {},
    },
  },
  rules: {
    'import/no-named-as-default': 0,
    'arrow-body-style': 'off',
    'no-underscore-dangle': 'off',
    'no-autofix/arrow-body-style': 'error',
    'react/jsx-filename-extension': [
      'warn',
      {
        extensions: ['.js', '.jsx', '.json', '.native.js'],
      },
    ],
    'react/prop-types': [
      'error',
      {
        skipUndeclared: true,
      },
    ],
    'prettier/prettier': ['error', prettier],
  },
};
