const icon = {
  inChatting: require('./inChatting.png'),
  onChatting: require('./onChatting.png'),
  inPersonal: require('./inPersonal.png'),
  onPersonal: require('./onPersonal.png'),
};
export default icon;
