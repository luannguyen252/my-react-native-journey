# React Native Button Integration Demo


How to run:

1. Fork this repo
2. Run npm install in the root of the repo
3. Set your button app id in android/app/src/main/AndroidManifest.xml:30
4. Launch your simuator or plug in your device and run "react-native run-android"


For more info: http://link-to-blogpost.com
