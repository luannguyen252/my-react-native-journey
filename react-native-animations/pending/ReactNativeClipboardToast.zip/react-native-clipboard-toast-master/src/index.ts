import ClipboardToast from './clipboard-toast';

export default ClipboardToast;
