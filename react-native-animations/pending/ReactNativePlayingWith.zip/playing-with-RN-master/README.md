# react-native-simplest-radio-buttons
simple logic for checkboxes in RN.


Demo:

![Demo](/images/demo.gif)

