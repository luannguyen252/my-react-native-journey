export default {
    black_opacity: 'rgba(0,0,0,0.15)',
    white: '#ffffff',
    black: '#020203',
    orange: '#f6bd60',
    yellow: '#f9c74f',
    off_white: '#e8eddf',
    pink: '#f5cac3',
    grey_green: '#84a59d',
    dark_grey: '#ddd',
    light_green: '#faf9f9',
    dark_pink: '#f28482',
}