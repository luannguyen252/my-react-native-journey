export const markers = [
  {
    key: 1,
    coordinate: {latitude: 37.77931340923996, longitude: -122.43387947968404}
  },
  {
    key: 2,
    coordinate: {latitude: 37.795807676669625, longitude: -122.44169957725602}
  },
  {
    key: 3,
    coordinate: {latitude: 37.8008178640208, longitude: -122.41147595298804}
  },
  {
    key: 4,
    coordinate: {latitude: 37.76198002475623, longitude: -122.41358949470275}
  }
]
