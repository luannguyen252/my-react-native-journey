## Run the example

- [View it with Exponent](https://getexponent.com/@rncommunity/react-native-tab-view-demos)
- Clone this repository, run `npm install` within this directory, and open it using [XDE](https://docs.getexponent.com/versions/latest/introduction/installation.html).
