const exampleImage = 1 //require("../assets/images/example.jpg");

const allImages = {exampleImage}

export default allImages;