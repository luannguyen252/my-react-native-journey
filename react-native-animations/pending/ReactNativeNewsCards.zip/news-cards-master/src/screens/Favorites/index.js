import Favorites from './Favorites'
export default Favorites 