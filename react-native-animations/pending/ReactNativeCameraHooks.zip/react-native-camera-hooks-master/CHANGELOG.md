We follow semantic versioning.

See the [releases](https://github.com/reime005/react-native-camera-hooks/releases) page on GitHub for information regarding each release.