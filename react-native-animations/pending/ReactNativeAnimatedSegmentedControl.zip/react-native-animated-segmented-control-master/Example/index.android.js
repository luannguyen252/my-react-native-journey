import { AppRegistry } from 'react-native';
import App from './js/App';

AppRegistry.registerComponent('Example', () => App);
