import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  statusBar: { flex: 0 },
  flexOne: {},
});

export default styles;
