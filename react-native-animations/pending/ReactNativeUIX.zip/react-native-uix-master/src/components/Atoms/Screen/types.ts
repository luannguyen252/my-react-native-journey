import { ViewProps } from "react-native";

export interface ScreenProps extends ViewProps {}
