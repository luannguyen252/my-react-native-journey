export { default } from './PageSlider';
