---
id: starter
title: Moti Starter Project
sidebar_label: Starter Project
---

If you're starting a project from scratch, or just want to play around, you can use the Expo + Moti [starter template](https://github.com/expo/examples/tree/master/with-moti).

```sh
npx create-react-native-app -t with-moti
```

Thanks to Evan Bacon for making that!
