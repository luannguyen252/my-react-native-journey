# ExpandabbleList

It is a expandableList component realized in react-native

## Preview

<div align="center">
  <img width="375" src="./preview/simple-demo.gif">
  <img width="375" src="./preview/qq-page-demo.gif">
</div>

## Demo Codes

[SimpleListPage](./src/pages/SimpleListPage/index.js)
[QQPage](./src/pages/QQPage/index.js)
