module.exports = {
  printWidth: 100,
  bracketSpacing: true,
  jsxBracketSameLine: false,
  singleQuote: true,
  trailingComma: 'es5',
  tabWidth: 2,
};
