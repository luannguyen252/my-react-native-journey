import TabBar from './TabBar/TabBar';
export default TabBar;
module.exports = TabBar;
