import Message from '../../resources/img/messageIcon.png';
import Social from '../../resources/img/socialIcon.png';
import Lever from '../../resources/img/leverIcon.png';
import Tune from '../../resources/img/tuneIcon.png';
import Bell from '../../resources/img/bellIcon.png';
import TuneView from './TuneViewIcon';

export default {
  TuneView,
  Message,
  Social,
  Lever,
  Bell,
  Tune,
};
