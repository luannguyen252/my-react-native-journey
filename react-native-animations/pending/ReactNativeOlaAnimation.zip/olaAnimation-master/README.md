# OLA Splash Screen Animation

Ola splash screen animation similar to reveal animation in android. Purely in JS. Runs on both android and ios.


![Alt text](/images/one.gif?raw=true "Ola android Animation")
![Alt text](/images/two.gif?raw=true "Ola ios Animation")

### Inspiration
ola app

# License

 - [MIT](https://github.com/ronak301/react-native-submit-button/blob/master/LICENSE.txt).  © Ronak Kothari