import RNMusicPicker from './src/RNMusicPicker/RNMusicPicker';
export default RNMusicPicker;
module.exports = RNMusicPicker;
