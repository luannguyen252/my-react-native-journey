import Tags from './Tags';
export default Tags;
