import StarRating from "./StarRating";

export default StarRating;
