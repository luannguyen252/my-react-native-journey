import React from 'react';
import Root from './src/Root';

export default function App() {
  return <Root/>
}
