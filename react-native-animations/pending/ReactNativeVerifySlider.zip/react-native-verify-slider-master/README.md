# react-native-verify-slider
Verification slider for React Native

<img src="https://github.com/kurzyx/react-native-verify-slider/blob/master/screenshots/slider.gif?raw=true">
