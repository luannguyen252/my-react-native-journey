import { main } from "./src/main";
export default main