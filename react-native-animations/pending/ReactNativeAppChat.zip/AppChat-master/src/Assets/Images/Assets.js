const Assets = {
  background: require('./background.jpg'),
  send: require('./send.png'),
  send1: require('./send1.png'),
};
export default Assets;
