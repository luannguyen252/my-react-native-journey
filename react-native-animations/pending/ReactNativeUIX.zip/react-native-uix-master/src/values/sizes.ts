export default {
  spacing: {
    xs: 5,
    sm: 10,
    md: 20,
    lg: 30,
  },
  listCellActionWidth: 75,
};
