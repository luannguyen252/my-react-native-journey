# react-native-animated-tabBar

![demo](https://github.com/samuel3105/react-native-animated-tabBar/blob/master/examples/example.gif)
