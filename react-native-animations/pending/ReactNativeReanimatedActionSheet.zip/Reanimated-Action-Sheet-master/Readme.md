
# Project Files for Reanimated Action Sheet

# Tutorial Video 

 [React Native Animated Actionsheet Tutorial](https://youtu.be/tLQjGHDiRkM)

### Branches

`master - starter project (boiler plate)`

`complete - for completed project`
