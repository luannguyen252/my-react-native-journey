/**
 * Day 
 * 
 */
'use strict';

import React,{ Component } from 'react';
import { Image,StyleSheet,Text,TouchableHighlight,View } from 'react-native';
import Util from './utils';

export default class extends Component{
  render() {
    return(
      <View></View>
    )
  }
}

const styles = StyleSheet.create({

});

