module.exports = {
  docs: [
    'gettingstarted',
    'screenshots',
    { type: 'category', label: 'Components', items: ['chart', 'line', 'area', 'verticalaxis', 'horizontalaxis', 'tooltip', 'types'] },
  ],
}
