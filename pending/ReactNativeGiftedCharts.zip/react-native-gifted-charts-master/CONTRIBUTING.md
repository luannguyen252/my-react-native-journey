# Contributions are welcome 🤝

Pull requests are most welcome! Please npm run test and npm run lint before push. Don't forget to add a title and a description that explain the issue you're trying to solve and your suggested solution. Screenshots and gifs are VERY helpful. Please do NOT format the files as we are trying to keep a unified syntax and the reviewing process fast and simple.
