### 0.4.0 (2020-03-10)

##### Breaking Changes

*  api changes/added swipe functionality ([2da913c1](https://github.com/Lkubok/react-native-radio-trimmer/commit/2da913c16209d3cfc83f0d35e2de77c13f0e88d6))

#### 0.2.2 (2020-03-10)

##### Documentation Changes

*  added generate-changelog package ([a6fbe3a2](https://github.com/Lkubok/react-native-radio-trimmer/commit/a6fbe3a2fcad4a85fa30ef641eef97471845b1c9))

##### Other Changes

*  row funcionality ([e23ae5e4](https://github.com/Lkubok/react-native-radio-trimmer/commit/e23ae5e4f6916ae85591275b2c1595fd6e264362))

