export default {
    backgroundColor: 'white',
    tabHeight: 64,
    circleSize: 40,
    circleAnimationDurationMs: 100,
};
