
global.React = require('react');
global.ReactDOM = require('react-dom');
global.Animated = require('../../lib/targets/react-dom');
global.createClass = require("create-react-class");