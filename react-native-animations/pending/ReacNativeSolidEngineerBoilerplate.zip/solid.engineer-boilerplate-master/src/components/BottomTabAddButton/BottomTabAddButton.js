import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import Colors from 'themes/CommonColors';
import CommonSize from 'themes/CommonSize';
import Icon from 'react-native-vector-icons/AntDesign';

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    width: CommonSize.CommonWidth.p30 + 10,
    alignItems: 'center',
  },
  background: {
    position: 'absolute',
    top: 0,
  },
  button: {
    top: -45.5,
    justifyContent: 'center',
    alignItems: 'center',
    width: 65,
    height: 65,
    borderRadius: 60,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 20,
    },
    shadowOpacity: 0.29,
    shadowRadius: 15.65,
    elevation: 2,
    backgroundColor: Colors.backgroundWhite,
  },
  buttonInside: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 58,
    height: 58,
    borderRadius: 64,
    backgroundColor: Colors.bottomActiveBlue,
  },
});

export const TabBg = ({ color = '#FFFFFF', ...props }) => (
  <Svg viewBox="0 0 289 145" {...props}>
    <Path
      class="cls-1"
      fill={color}
      strokeWidth={1.5}
      stroke={Colors.white}
      d="M144,864h0a102.3,102.3,0,0,1,75.41,33.17l.46.49a92.65,92.65,0,0,0,136.88-.34h0A101.64,101.64,0,0,1,432,864h0v144H144Z"
      transform="translate(-143.5 -863.5)"
    />
  </Svg>
);

const ChargeButton = ({ navigation }) => (
  <TouchableOpacity onPress={() => navigation.navigate('SearchModal')} style={styles.button}>
    <View style={styles.buttonInside}>
      <Icon name="plus" color={Colors.backgroundWhite} size={35} />
    </View>
  </TouchableOpacity>
);

const BottomTabAddButton = ({ params, navigation }) => (
  <View style={styles.container} pointerEvents="box-none">
    <TabBg color={Colors.backgroundWhite} style={styles.background} />
    <ChargeButton navigation={navigation} />
  </View>
);

export default BottomTabAddButton;
