import Image from './src/Image';

export {Image};
