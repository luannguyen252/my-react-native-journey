module.exports = {
  roomName: null,
};
