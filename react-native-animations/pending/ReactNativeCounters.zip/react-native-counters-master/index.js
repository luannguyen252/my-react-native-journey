import Counter from './src/components/counter';

// İmport Main Component
export default Counter;