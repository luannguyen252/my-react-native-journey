# :iphone: Animações com React Native

- Utilizando o Animated do React Native para aplicar animações na aplicação, melhorando a experiência para o usuário.

    ![Cena 01](cena01.png)    ![Cena 02](cena02.png)

    ![Cena 03](cena03.png)    ![Cena 04](cena04.png)
