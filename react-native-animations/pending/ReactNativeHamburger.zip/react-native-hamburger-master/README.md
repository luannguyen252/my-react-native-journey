# react-native-hamburger
Animated fully configurable hamburger menu for react-native!

```
npm install react-native-hamburger --save
import Hamburger from 'react-native-hamburger';
```

![alt tag](gif/hamburger.gif)
