module.exports = {
  branches: 'master',
};
