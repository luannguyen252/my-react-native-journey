# React Navigation - Structuring Your App 
Learn how to use The Stack Navigator, Drawer Navigator and Tab Navigator in Combination to create the perfect navigation Flow. 



## YouTube Tutorial Video 
* ###  [React Navigation - Structuring Your App ](https://youtu.be/5f5VEEmMSyE) 

## Installation Instructions 

```js
 $ git clone https://github.com/nathvarun/React-Navigation-Structuring-Your-App.git
 $ cd React-Navigation-Structuring-Your-App
 $ npm install 
```
