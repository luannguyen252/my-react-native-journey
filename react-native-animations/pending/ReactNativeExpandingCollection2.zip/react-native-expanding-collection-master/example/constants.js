const cities = [
  {
    id: '654831654',
    name: 'New York',
    img: 'https://media-cdn.tripadvisor.com/media/photo-s/0e/9a/e3/1d/freedom-tower.jpg',
    blob: 'New York is a cool',
    rating: 4,
    reviews: [
      {
        userName: 'Ebbe Ugwu',
        userAvatar: 'https://randomuser.me/api/portraits/men/83.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'FEB 14th',
      }, {
        userName: 'Jakob Merquier',
        userAvatar: 'https://randomuser.me/api/portraits/men/46.jpg',
        review: ' aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
        date: 'JUL 8th'
      }, {
        userName: 'Helena Waldenz',
        userAvatar: 'https://randomuser.me/api/portraits/women/9.jpg',
        review: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
        date: 'DEC 1st',
      }, {
        userName: 'Mark Philips',
        userAvatar: 'https://randomuser.me/api/portraits/men/45.jpg',
        review: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
        date: 'MAR 23rd'
      }
    ],
    coordinates: [40.785091, 'North', -73.968285, 'West']
  },
  {
    id: '32164893',
    name: 'London',
    img: 'https://i.ytimg.com/vi/7BymziTFM2E/maxresdefault.jpg',
    blob: 'The buzzing heart of Great Britain',
    rating: 5,
    reviews: [
      {
        userName: 'Monique Shultz',
        userAvatar: 'https://randomuser.me/api/portraits/women/6.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'APR 15th'
      }, {
        userName: 'Sasha Abrasowich',
        userAvatar: 'https://randomuser.me/api/portraits/women/18.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'MAR 12ve'
      }, {
        userName: 'Michel Cors',
        userAvatar: 'https://randomuser.me/api/portraits/men/25.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'JUN 5th'
      }, {
        userName: 'Michelle Redriguez',
        userAvatar: 'https://randomuser.me/api/portraits/women/88.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'NOV 19th'
      }, {
        userName: 'Paul Stenton',
        userAvatar: 'https://randomuser.me/api/portraits/men/88.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'JUL 30th'
      }
    ],
    coordinates: [51.509865, 'North', -0.118092, 'West']
  },
  {
    id: '65465654',
    name: 'Sydney',
    img: 'https://media-cdn.tripadvisor.com/media/photo-s/03/9b/2e/15/sydney.jpg',
    blob: 'Sydney is the city of fireworks',
    rating: 4,
    reviews: [
      {
        userName: 'Patrice Allent',
        userAvatar: 'https://randomuser.me/api/portraits/men/6.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'MAR 16th'
      }, {
        userName: 'Adam Balzack',
        userAvatar: 'https://randomuser.me/api/portraits/men/18.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'SEP 1st'
      }, {
        userName: 'Kate Novak',
        userAvatar: 'https://randomuser.me/api/portraits/women/15.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'MAY 8th'
      }, {
        userName: 'Catherine Podolski',
        userAvatar: 'https://randomuser.me/api/portraits/women/66.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'MAR 22nd'
      }, {
        userName: 'John Smith',
        userAvatar: 'https://randomuser.me/api/portraits/men/22.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'SEP 16th'
      }
    ],
    coordinates: [-33.865143, 'South', 151.209900, 'East']
  },
  {
    id: '564541131',
    name: 'Paris',
    img: 'https://images8.alphacoders.com/376/thumb-1920-376369.jpg',
    blob: 'Starving to death is still considered an art',
    rating: 5,
    reviews: [
      {
        userName: 'Pete Jim',
        userAvatar: 'https://randomuser.me/api/portraits/men/8.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'MAR 14th'
      }, {
        userName: 'Scott Douglas',
        userAvatar: 'https://randomuser.me/api/portraits/men/16.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'APR 1st'
      }, {
        userName: 'Micheal Linkvist',
        userAvatar: 'https://randomuser.me/api/portraits/men/25.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'JUN 23rd'
      }, {
        userName: 'Eve Garcia',
        userAvatar: 'https://randomuser.me/api/portraits/women/1.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'JAN 1st',
      }
    ],
    coordinates: [48.858093, 'North', 2.294694, 'East']
  },
  {
    id: '5645645643',
    name: 'Moscow',
    img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Moscow-City2015.jpg/440px-Moscow-City2015.jpg',
    blob: 'The power of Moscow pride should never be underestimated',
    rating: 4,
    reviews: [
      {
        userName: 'Abdul Amman',
        userAvatar: 'https://randomuser.me/api/portraits/men/75.jpg',
        review: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis...',
        date: 'DEC 31st'
      }, {
        userName: 'Jaques Paull',
        userAvatar: 'https://randomuser.me/api/portraits/men/71.jpg',
        review: ' aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
        date: 'OCT 8th'
      }, {
        userName: 'Maria Hohenzollern',
        userAvatar: 'https://randomuser.me/api/portraits/women/81.jpg',
        review: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
        date: 'JUL 10th'
      }, {
        userName: 'Marie Vasquez',
        userAvatar: 'https://randomuser.me/api/portraits/women/46.jpg',
        review: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
        date: 'MAY 20th'
      }
    ],
    coordinates: [55.751244, 'North', 37.618423, 'East']
  },
]

export { cities };
