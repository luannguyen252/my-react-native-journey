import React from 'react';
import { Image, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import Colors from 'themes/CommonColors';
import generalIcon from 'themes/GeneralIcon';
import SVGIcon from 'themes/icon';
import ROUTES from './ConstRoute';

const styles = StyleSheet.create({
  imageStyle: {
    width: 20,
    height: 20,
    borderRadius: 20,
  },
});

export default function getBottomTabIcon(routeName, color) {
  switch (routeName) {
    case ROUTES.FIRST_SCREEN:
      return <SVGIcon type={generalIcon.HOME} colour={color} />;
    case ROUTES.EXPLORE_SCREEN:
      return <SVGIcon type={generalIcon.MARKET} colour={color} />;
    case ROUTES.STATISTICS_SCREEN:
      return <SVGIcon type={generalIcon.STATISTICS} colour={color} />;
    case ROUTES.NOTIFICATION_SCREEN:
      return <SVGIcon type={generalIcon.NOTIFICATION} colour={color} />;
    default:
      return null;
  }
}
