import Pages from './src/components/pages';
import Indicator from './src/components/indicator';

export { Pages, Indicator };
