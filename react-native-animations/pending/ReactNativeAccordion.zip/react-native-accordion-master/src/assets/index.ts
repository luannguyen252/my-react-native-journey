export const images = {
  arrowUp: require("../../src/assets/arrow-up.png"),
  arrowDown: require("../../src/assets/arrow-down.png"),
};
