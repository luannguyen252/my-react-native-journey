import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  actionContainer: {
    marginRight: 20,
  },

  button: {
    marginRight: 10,
  },
});
