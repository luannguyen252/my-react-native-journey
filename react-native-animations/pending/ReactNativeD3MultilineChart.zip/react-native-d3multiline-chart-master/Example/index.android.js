import React, { Component } from 'react';
import {
  AppRegistry,
} from 'react-native';

import Example from './app'

AppRegistry.registerComponent('Example', () => Example);