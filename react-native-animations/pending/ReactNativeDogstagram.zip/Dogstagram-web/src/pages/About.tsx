import React from 'react';
import {Text} from 'react-native';

export default () => <Text>This is a useless about page</Text>;
