const extraNodeModules = require('node-libs-browser');

module.exports = {
  extraNodeModules,
};