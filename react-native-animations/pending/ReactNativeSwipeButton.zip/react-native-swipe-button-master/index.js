import SwipeButton from './src/SwipeButton';

export default SwipeButton;
