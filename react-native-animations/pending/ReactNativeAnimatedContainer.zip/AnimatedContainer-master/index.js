import {AnimatedContainer} from "./src/AnimatedContainer";
export {
  AnimatedContainer
};