# Releasing

This package is released automatically using
[semantic-release](https://github.com/semantic-release/semantic-release).
