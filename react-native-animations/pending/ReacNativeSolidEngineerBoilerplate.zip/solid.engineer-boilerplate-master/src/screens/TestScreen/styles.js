import { StyleSheet } from 'react-native';
import Colors from 'themes/CommonColors';

const styles = StyleSheet.create({
  flexOne: {
    flex: 1,
    backgroundColor: Colors.backgroundGray,
  },
  headerContainer: {
    paddingLeft: 30,
  },
});

export default styles;
