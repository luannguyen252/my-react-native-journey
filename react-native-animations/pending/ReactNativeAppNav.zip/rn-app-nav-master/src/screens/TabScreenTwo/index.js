import React from 'react';
import { View, Text } from 'react-native';

const TabScreenTwo = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Settings screen</Text>
    </View>
  );
};

export default TabScreenTwo;
