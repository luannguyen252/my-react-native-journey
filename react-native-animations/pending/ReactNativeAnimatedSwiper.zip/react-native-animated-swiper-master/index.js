import AnimatedSwiper from './src/'
module.exports = AnimatedSwiper
