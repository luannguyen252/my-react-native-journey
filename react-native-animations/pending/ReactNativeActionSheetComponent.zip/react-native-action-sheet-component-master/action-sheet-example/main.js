import Expo from 'expo';
import ActionSheetExample from './ActionSheetExample';

Expo.registerRootComponent(ActionSheetExample);
