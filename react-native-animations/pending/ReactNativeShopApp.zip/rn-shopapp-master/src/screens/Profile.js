import React, { Component } from 'react';
import { View, Text } from 'react-native';

class Profile extends Component {
  state = {};
  render() {
    return (
      <View>
        <Text>Hello there!</Text>
      </View>
    );
  }
}

export default Profile;
