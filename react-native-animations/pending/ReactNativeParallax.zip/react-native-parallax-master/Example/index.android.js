/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');

React.AppRegistry.registerComponent('Example', () => require('./app'));
