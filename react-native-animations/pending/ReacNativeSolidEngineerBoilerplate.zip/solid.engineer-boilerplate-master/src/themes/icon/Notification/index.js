import * as React from 'react';
import Svg, { Path } from 'react-native-svg';

const Notification = ({ colour, width, height }) => (
  <Svg viewBox="0 0 145 145" width={width} height={height}>
    <Path
      strokeMiterlimit={10}
      fill={colour}
      d="M495,504V489.62h-.2C492.32,459.42,465.16,432,432,432s-60.34,27.42-62.82,57.62q-.18,2.24-.18,4.5c0,1.28.05,2.55.14,3.81L369,504c-5.77,3.88-9,16.86-9,21.62,0,10,14.49,18.71,36,23.38a180.82,180.82,0,0,0,72,0c21.51-4.67,36-13.39,36-23.38C504,520.88,500.73,507.87,495,504Z"
      transform="translate(-359.5 -431.5)"
    />
    <Path
      strokeMiterlimit={10}
      fill={colour}
      d="M405,561.62c0,7.94,10.28,14.38,23,14.38H436c12.69,0,23-6.44,23-14.38a215.26,215.26,0,0,1-54,0Z"
      transform="translate(-359.5 -431.5)"
    />
  </Svg>
);

export default Notification;
