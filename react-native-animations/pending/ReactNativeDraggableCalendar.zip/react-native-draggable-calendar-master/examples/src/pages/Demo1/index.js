import React, {PureComponent} from 'react';

import {DraggableCalendar} from 'react-native-draggable-calendar';

export class Demo1 extends PureComponent {
  render() {
    return <DraggableCalendar/>;
  }
}