const globalStyle = {
  flexRow: {
    flexDirection: 'row',
  },
};

export default globalStyle;
