export type Mode = 'light' | 'dark'
