//
//  NewsCards-Bridging-Header.h
//  NewsCards
//
//  Created by idanlevi on 25/06/2021.
//

#ifndef NewsCards_Bridging_Header_h
#define NewsCards_Bridging_Header_h


#endif /* NewsCards_Bridging_Header_h */
