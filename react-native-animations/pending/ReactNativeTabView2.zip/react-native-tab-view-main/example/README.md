# Run the example

- [View it with Expo](https://expo.io/@satya164/react-native-tab-view-demos)
- Run the example locally
  - Clone the repository and `cd` to this directory
  - Run `yarn` to install the dependencies
  - Run `yarn start` to start the packager
  - Scan the QR Code with the Expo app
