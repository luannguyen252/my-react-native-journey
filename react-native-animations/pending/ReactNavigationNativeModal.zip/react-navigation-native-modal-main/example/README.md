# Run the example

- [View it with Expo](https://expo.io/@satya164/react-navigation-native-modal-example)
- Run the example locally
  - Clone the repository and run `yarn bootstrap` to install the dependencies
  - Run `yarn example start` to start the packager
  - Scan the QR Code with the Expo app
