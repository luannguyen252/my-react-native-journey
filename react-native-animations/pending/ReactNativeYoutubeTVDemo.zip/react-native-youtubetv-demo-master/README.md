YouTube TV List demo

Link to blog: https://medium.com/p/7477f004005e

===

Here are the branches to the four steps of re-creating the animated 
list.

https://github.com/birkir/react-native-youtubetv-demo/tree/step/1

https://github.com/birkir/react-native-youtubetv-demo/tree/step/2

https://github.com/birkir/react-native-youtubetv-demo/tree/step/3

https://github.com/birkir/react-native-youtubetv-demo/tree/step/4
