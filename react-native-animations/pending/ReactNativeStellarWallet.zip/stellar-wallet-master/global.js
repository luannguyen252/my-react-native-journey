// Inject node globals into React Native global scope.
global.Buffer = require("buffer").Buffer;
global.process = require("process");
