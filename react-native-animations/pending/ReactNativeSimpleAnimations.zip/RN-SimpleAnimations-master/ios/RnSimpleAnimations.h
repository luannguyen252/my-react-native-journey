#import <React/RCTViewManager.h>

@interface RnSimpleAnimations : RCTViewManager

@end
