### Which OS ?

### Version
Which versions are you using:

- react-native-swiper v?
- react-native v0.?.?

### Expected behaviour



### Actual behaviour


### How to reproduce it>
To help us, please fork this component, modify one example in examples folder to reproduce your issue and include link here.
-

### Steps to reproduce
1.
2.
3.
