import BottomDrawer from './src/BottomDrawer';

export default BottomDrawer;
