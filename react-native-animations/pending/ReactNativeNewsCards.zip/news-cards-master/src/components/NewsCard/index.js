import NewsCard from './NewsCard'
export default NewsCard 