import ParallaxHeader from './parallax-header';

export default ParallaxHeader;
