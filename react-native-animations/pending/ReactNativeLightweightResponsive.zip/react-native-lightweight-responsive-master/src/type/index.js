const RESPONSIVE_TYPE = {
  'WIDTH': 'WIDTH',
  'HEIGHT': 'HEIGHT',
  'FONT': 'FONT',
};

export {
  RESPONSIVE_TYPE,
};