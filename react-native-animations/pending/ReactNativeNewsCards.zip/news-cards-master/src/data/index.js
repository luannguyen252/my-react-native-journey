import NewsCategoriesData from './news_categories_us.json';
import NewsCountriesData from './news_countries.json';
import NewsSortTypesData from './news_sort_types.json';

export {
    NewsCategoriesData,
    NewsCountriesData,
    NewsSortTypesData
}