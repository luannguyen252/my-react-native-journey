import React from 'react';
import { View, Text } from 'react-native';

const TabScreenOne = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Home screen</Text>
    </View>
  );
};

export default TabScreenOne;
