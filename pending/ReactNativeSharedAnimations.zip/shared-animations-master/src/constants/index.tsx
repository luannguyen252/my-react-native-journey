export const LIBRARY_NAME = 'react-native-shared-animation'
