

import React from 'react'
import {
    View,
    Text
} from "react-native";
import Header from '../components/Header';

const Home = () => {
    return (
        <Header text="Header" />
    )
}

export default Home
