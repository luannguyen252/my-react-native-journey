//
//  MFLReactFancyLabelManager.h
//  ReactNativeFancyLabel
//
//  Created by TJ Fallon on 1/11/16.
//  Copyright © 2016 Skillz. All rights reserved.
//

#import "RCTViewManager.h"

@interface MFLReactFancyLabelManager : RCTViewManager

@end

