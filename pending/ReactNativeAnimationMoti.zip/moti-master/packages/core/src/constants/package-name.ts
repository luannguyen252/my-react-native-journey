// import Package from '../../package.json'
export const PackageName = 'moti'
