import init from './app';

init();
