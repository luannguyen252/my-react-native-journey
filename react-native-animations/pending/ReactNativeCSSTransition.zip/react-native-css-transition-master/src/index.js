import {Transition} from "./Transition";

export default Transition;