import React, {Component} from 'react'
import {View} from 'react-native'

class PlaceSearchResult extends Component {
  render() {
    return <View />
  }
}

export default PlaceSearchResult
