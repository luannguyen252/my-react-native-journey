import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import CommonSize from 'themes/CommonSize';
import globalStyle from 'themes/GlobalStyle';
import Icon from 'react-native-vector-icons/Ionicons';
import Colors from 'themes/CommonColors';
import CategoryTag from './CategoryTag';

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingHorizontal: CommonSize.CommonWidth.horizontalSpacing,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
});

const HeaderComponent = ({ params }) => (
  <View style={styles.container}>
    {/* <View style={globalStyle.flexRow}>
      <CategoryTag isActive tagContent="MEN" />
      <CategoryTag tagContent="WOMEN" />
    </View>
    <View style={globalStyle.flexRow}>
      <TouchableOpacity>
        <Icon name="search-outline" size={25} color={Colors.inActiveCategoryGray} />
      </TouchableOpacity>
      <TouchableOpacity>
        <Icon name="cart-outline" size={25} color={Colors.inActiveCategoryGray} />
      </TouchableOpacity>
    </View> */}
  </View>
);

export default HeaderComponent;
