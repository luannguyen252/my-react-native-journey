import ReadMore from './example/src/ReadMore';

export default ReadMore;
