#import <React/RCTViewManager.h>

@interface RNWebGLARKitManager : RCTViewManager

@end
