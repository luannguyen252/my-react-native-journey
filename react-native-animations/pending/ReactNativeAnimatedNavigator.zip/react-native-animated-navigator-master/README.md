# react-native-animated-navigator
React Native's Navigator implemented with the Animated API
