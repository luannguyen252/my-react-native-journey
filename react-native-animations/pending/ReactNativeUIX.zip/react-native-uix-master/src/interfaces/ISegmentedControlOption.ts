export interface ISegmentedControlOption {
  id: number | string;
  label: string;
  onPress: () => void;
}
