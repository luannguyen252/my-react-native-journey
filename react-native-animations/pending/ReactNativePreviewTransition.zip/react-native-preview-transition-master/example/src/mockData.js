import IMAGE_BERTHE from './res/img/berthe_morisot.jpg';
import IMAGE_CLAUDE from './res/img/ClaudeMonet.jpg';
import IMAGE_EDGAR from './res/img/EdgarDegas.jpg';
import IMAGE_EDOUARD from './res/img/ÉdouardManet.jpg';
import IMAGE_PAUL from './res/img/PaulCézanne.jpg';

const data = [
  {
    title: 'Berthe Morisot',
    liked: false,
    img: IMAGE_BERTHE,
  },
  {
    title: 'Claude Monet',
    img: IMAGE_CLAUDE,
  },
  {
    title: 'Edgar Degas',
    liked: false,
    img: IMAGE_EDGAR,
  },
  {
    title: 'Édouard Manet',
    liked: false,
    img: IMAGE_EDOUARD,
  },
  {
    title: 'Paul Cézanne',
    liked: false,
    img: IMAGE_PAUL,
  },
  {
    title: 'Berthe Morisot',
    liked: false,
    img: IMAGE_BERTHE,
  },
  {
    title: 'Claude Monet',
    img: IMAGE_CLAUDE,
  },
  {
    title: 'Edgar Degas',
    liked: false,
    img: IMAGE_EDGAR,
  },
  {
    title: 'Édouard Manet',
    liked: false,
    img: IMAGE_EDOUARD,
  },
  {
    title: 'Paul Cézanne',
    liked: false,
    img: IMAGE_PAUL,
  },
  {
    title: 'Berthe Morisot',
    liked: false,
    img: IMAGE_BERTHE,
  },
  {
    title: 'Claude Monet',
    img: IMAGE_CLAUDE,
  },
  {
    title: 'Edgar Degas',
    liked: false,
    img: IMAGE_EDGAR,
  },
  {
    title: 'Édouard Manet',
    liked: false,
    img: IMAGE_EDOUARD,
  },
  {
    title: 'Paul Cézanne',
    liked: false,
    img: IMAGE_PAUL,
  },
];

export default data;
