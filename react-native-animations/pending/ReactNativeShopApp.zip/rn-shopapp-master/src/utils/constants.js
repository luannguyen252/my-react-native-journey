export const TOKEN = '@shopapp/token';
