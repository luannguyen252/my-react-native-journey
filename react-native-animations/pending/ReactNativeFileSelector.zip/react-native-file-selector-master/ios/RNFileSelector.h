
#import "RCTUIManager.h"

#import <FileBrowser/FileBrowser-Swift.h>

@interface RNFileSelector : NSObject <RCTBridgeModule>

@end
  
