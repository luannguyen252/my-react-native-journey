import * as React from 'react';
import Svg, { Path } from 'react-native-svg';

const Market = ({ colour, width, height }) => (
  <Svg viewBox="0 0 145 145" width={width} height={height}>
    <Path
      strokeMiterlimit={10}
      fill={colour}
      transform="translate(-359.5 -215.5)"
      d="M427.33,224.48a67.76,67.76,0,1,0,67.77,67.76H427.33Z"
    />
    <Path
      strokeMiterlimit={10}
      fill={colour}
      transform="translate(-359.5 -215.5)"
      d="M436.45,216h-.21v67.75H504A67.66,67.66,0,0,0,436.45,216Z"
    />
  </Svg>
);

export default Market;
