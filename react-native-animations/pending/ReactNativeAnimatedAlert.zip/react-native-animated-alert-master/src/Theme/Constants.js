export default {
  start: "start",
  center: "center",
  end: "end",
  minimumHideDuration: 1000,
  animatedLogoDuration: 200,
  center: "center",
  contain: "contain",
  cover: "cover",
  repeat: "repeat",
  stretch: "stretch"
};
