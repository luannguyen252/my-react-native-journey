---

title: Screenshots
id: screenshots

---

To give you and idea of the options this library offers, here are some end results.

![Chart example](/img/screenshots/example1.png)
![Chart example](/img/screenshots/example2.png)
![Scrolling example](/img/Scrollable.gif)
![Tooltip example](/img/Tooltip.gif)
![Chart example](/img/screenshots/example3.png)
![Chart example](/img/screenshots/example4.png)


![Smoothing 1](/img/smooth.png)
![Smoothing 2](/img/smoothing.png)
![Chart example](/img/screenshots/example5.png)