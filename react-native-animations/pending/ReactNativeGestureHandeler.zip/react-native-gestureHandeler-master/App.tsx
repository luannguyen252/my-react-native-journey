import React from 'react';
import { Gesture } from './src/index'

export default function App() {
	return (
			<Gesture></Gesture>
	);
}