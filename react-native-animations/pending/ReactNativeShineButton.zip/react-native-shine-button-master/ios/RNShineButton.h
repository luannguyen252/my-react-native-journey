
#if __has_include("RCTBridgeModule.h")
#import "RCTViewManager.h"
#else
#import <React/RCTViewManager.h>
#endif

#import <WCLShineButton/WCLShineButton-Swift.h>
#import <React/RCTComponentEvent.h>

#import "RNImageHelper.h"

@interface RNShineButton : RCTViewManager

@end
  
