#!/bin/sh

$(dirname "$0")/post-link-ios.sh
$(dirname "$0")/post-link-android.sh
