module.exports = {
  extends: "../.eslintrc",
};
