type MapAnimationValueToProps = (animatedValuesFromContext: object) => object

export type MapValuesToProps = string | string[] | MapAnimationValueToProps | null
