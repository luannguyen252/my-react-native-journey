# DigitArc Hockey Animation

## Introduction

> Hockey Animation with React Native Gestures powered fully by React Native Reanimated and React Native Gesture Handler

## Installation

```bash
    npm install
    npm run start
    i
    a
```

## Example Usage

![alt text](https://github.com/DigitArc/ReactNativeHockey/blob/master/hockey-gif.gif)