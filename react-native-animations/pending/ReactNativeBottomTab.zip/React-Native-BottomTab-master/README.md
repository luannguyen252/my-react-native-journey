# React-Native-BottomTab
Animated bottom tab bar

npm package is ready!! 
[here is the link](https://github.com/sa8ab/reanimated-bottom-tabs) 

![Gif](https://i.imgur.com/NP3yRUB.gif)



**libraries used :**
* react-native-reanimated V2 (requires Hermes for android)
* react-native-vector-icons
