import Slides from './Slides';

export default Slides;
