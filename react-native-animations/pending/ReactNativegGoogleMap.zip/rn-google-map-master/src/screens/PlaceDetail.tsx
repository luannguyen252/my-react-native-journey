import React, {Component} from 'react'
import {View} from 'react-native'

class PlaceDetail extends Component {
  render() {
    return <View />
  }
}

export default PlaceDetail
