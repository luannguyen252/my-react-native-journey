import TabView from './src/'
module.exports = TabView
