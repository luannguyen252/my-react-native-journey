import TooltipAlert from "./src";

export default TooltipAlert;
