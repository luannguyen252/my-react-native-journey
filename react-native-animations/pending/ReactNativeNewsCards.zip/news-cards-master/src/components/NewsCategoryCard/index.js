import NewsCategoryCard from './NewsCategoryCard'
export default NewsCategoryCard 