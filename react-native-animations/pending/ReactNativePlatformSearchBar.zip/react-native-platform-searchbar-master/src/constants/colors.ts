export const iosBlue = '#007AFF';
export const iosLightPlaceholderGray = '#929296';
export const iosDarkPlaceholderGray = '#97979d';
export const androidLightPlaceholderGray = '#777777';
export const androidDarkPlaceholderGray = '#AAAAAA';
