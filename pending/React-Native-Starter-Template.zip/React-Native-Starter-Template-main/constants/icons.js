export const play = require("../assets/icons/play.svg");
export const settings = require("../assets/icons/configuration.svg");
export const feedback = require("../assets/icons/feedback.svg");

const icons = {play, settings, feedback}

export default icons;