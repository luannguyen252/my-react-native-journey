import React from 'react';

import AnimationExamples from './components/AnimationExamples';

export default function App() {
  return <AnimationExamples />;
}
