#import <UIKit/UIKit.h>
#import <React/RCTView.h>

@interface SajjadBlurOverlay : RCTView

@property (nonatomic, strong) NSString *blurStyle;
@property (nonatomic) BOOL vibrant;

@end
