import { connect } from 'react-redux';
import { decrement, increment } from 'redux/slices/counter/counterSlice';
import TestScreen from './TestScreen';

function mapStateToProps(state) {
  return {
    counter: state.counter.value,
  };
}

function mapDispatchToProps(dispatch) {
  return {
    increment: () => dispatch(increment()),
    decrement: () => dispatch(decrement()),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(TestScreen);
