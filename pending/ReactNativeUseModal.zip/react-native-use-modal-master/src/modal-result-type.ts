export enum ModalResultType {
  CONFIRM,
  CANCEL,
}
