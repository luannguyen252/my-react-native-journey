export const images = [
  {
    id: 1,
    name: "image 1",
    uri: require("../assets/1.jpg")
  },
  {
    id: 2,
    name: "image 2",
    uri: require("../assets/2.jpg")
  },
  {
    id: 3,
    name: "image 3",
    uri: require("../assets/3.jpg")
  },
  {
    id: 4,
    name: "image 4",
    uri: require("../assets/4.jpg")
  }
];
