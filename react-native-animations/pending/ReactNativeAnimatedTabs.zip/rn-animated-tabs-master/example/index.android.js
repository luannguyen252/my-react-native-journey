import { AppRegistry } from 'react-native';
import Example from './app';

AppRegistry.registerComponent('example', () => Example);
