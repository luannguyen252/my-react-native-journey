import React from 'react';

const VideoPlayerContext = React.createContext()

export default VideoPlayerContext