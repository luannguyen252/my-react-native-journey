import AnimatedPullToRefresh from './src/AnimatedPullToRefresh/index';

export default AnimatedPullToRefresh;
