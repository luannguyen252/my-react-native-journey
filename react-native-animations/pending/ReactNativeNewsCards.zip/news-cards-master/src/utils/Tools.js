export const capitalizeFirstLetter = (string) => string ? string.charAt(0).toUpperCase() + string.toLowerCase().slice(1) : ''
