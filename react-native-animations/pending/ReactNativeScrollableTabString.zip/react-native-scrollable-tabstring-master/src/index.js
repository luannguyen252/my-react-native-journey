import ScrollableTabString from './ScrollableTabString';

export default ScrollableTabString;
