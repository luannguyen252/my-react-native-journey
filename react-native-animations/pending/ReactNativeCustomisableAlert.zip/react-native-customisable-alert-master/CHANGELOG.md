# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.1.18](https://github.com/MaiconGilton/react-native-customisable-alert/compare/v0.1.17...v0.1.18) (2021-05-27)


### Features

* add style for the alert container ([56b14b3](https://github.com/MaiconGilton/react-native-customisable-alert/commit/56b14b3d3a5cc996bf6e82fe9cb4b62ec8c743d5))


### Bug Fixes

* rename containerStyle prop to backdropStyle ([f26e2ca](https://github.com/MaiconGilton/react-native-customisable-alert/commit/f26e2ca77abbfec93227f63ada5bbf28b2cb38b9))

### [0.1.17](https://github.com/MaiconGilton/react-native-customisable-alert/compare/v0.1.15...v0.1.17) (2021-05-23)


### Bug Fixes

* change React.Component type to React.ReactNode ([ee5d209](https://github.com/MaiconGilton/react-native-customisable-alert/commit/ee5d209e0f9d538f3c25c09ca3f31451c3dfa1cd))

# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### Bug Fixes

* set optional params ([d17abfe](https://github.com/MaiconGilton/react-native-customisable-alert/commit/d17abfe1560089f556b7c878bb740733f5aa9864))
