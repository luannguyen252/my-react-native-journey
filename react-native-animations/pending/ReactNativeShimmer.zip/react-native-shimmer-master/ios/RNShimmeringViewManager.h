//
//  RNShimmeringViewManager.h
//  RNShimmer
//
//  Created by Joel Arvidsson on 2016-03-03.
//  Copyright © 2016 Joel Arvidsson. All rights reserved.
//

#import <React/RCTViewManager.h>

@interface RNShimmeringViewManager : RCTViewManager

@end
