import AnimatedStack from './AnimatedStack';
export { SwipeMethod } from './AnimatedStack';

export default AnimatedStack;
