import Alert from './src/Alert/Alert';
export default Alert;
module.exports = Alert;
