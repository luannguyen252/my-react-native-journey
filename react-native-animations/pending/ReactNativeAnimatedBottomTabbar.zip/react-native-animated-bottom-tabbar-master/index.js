import TypeOne from './type1';
import TypeTwo from './type2';

export { TypeOne, TypeTwo };
