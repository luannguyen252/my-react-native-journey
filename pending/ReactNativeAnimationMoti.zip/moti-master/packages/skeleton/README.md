# Moti skeleton

First, install and setup `moti`.

Next, install `@motify/skeleton`:

```sh
yarn add @motify/skeleton
```

Finally, install peer dependencies:

```
expo install expo-linear-gradient
```
