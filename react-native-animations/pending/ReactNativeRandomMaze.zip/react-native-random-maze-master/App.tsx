import React from 'react';

import Maze from './components/Maze'

export default function App() {
  return (
    <Maze />
  );
}
