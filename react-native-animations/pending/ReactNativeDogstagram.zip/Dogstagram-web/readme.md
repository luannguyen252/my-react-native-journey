# dogstagram

> a simple app to test native app and web with nextjs (probably)

## running

```
yarn
yarn start (in one terminal)
yarn android (in another) // with emulator or physical device connected
```
