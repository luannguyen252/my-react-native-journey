import * as React from 'react';
import Svg, { Path } from 'react-native-svg';

const Home = ({ colour, width, height }) => (
  <Svg viewBox="0 0 144.76 144.54" width={width} height={height}>
    <Path
      strokeMiterlimit={10}
      fill={colour}
      transform="translate(-143.84 -215.78)"
      d="M208.47,222.38l-58.11,43.41a15,15,0,0,0-6,12v67a15,15,0,0,0,15,15h38.4l-.42-45h36.57v45h39.23a15,15,0,0,0,15-15v-67A15,15,0,0,0,282,265.79l-58.85-43.45C218.48,213.86,212.56,214.66,208.47,222.38Z"
    />
  </Svg>
);

export default Home;
