import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import BottomTabAddButton from 'components/BottomTabAddButton/BottomTabAddButton';
import React from 'react';
import { StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import TestScreen from 'screens/TestScreen';
import Colors from 'themes/CommonColors';
import CommonSize from 'themes/CommonSize';
import getBottomTabIcon from 'utils/BottomTabIcon';
import ROUTES from 'utils/ConstRoute';

const Tab = createBottomTabNavigator();

const SearchComponent = () => null;

const BottomTabStack = ({ navigation }) => {
  const insets = useSafeAreaInsets();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color }) => getBottomTabIcon(route.name, color),
      })}
      lazy
      tabBarOptions={{
        safeAreaInsets: { bottom: -insets.bottom },
        style: { height: 70, borderTopWidth: 0, backgroundColor: Colors.transparent },
        activeTintColor: Colors.bottomActiveBlue,
        inactiveTintColor: Colors.bottomTabInactiveGray,
        showLabel: false,
        tabStyle: { paddingBottom: 20, backgroundColor: Colors.backgroundWhite },
      }}
    >
      <Tab.Screen name={ROUTES.FIRST_SCREEN} component={TestScreen} />
      <Tab.Screen name={ROUTES.EXPLORE_SCREEN} component={TestScreen} />
      <Tab.Screen
        name={ROUTES.WALLET_SCREEN}
        component={SearchComponent}
        options={{
          tabBarButton: () => <BottomTabAddButton navigation={navigation} />,
        }}
      />
      <Tab.Screen name={ROUTES.STATISTICS_SCREEN} component={TestScreen} />
      <Tab.Screen name={ROUTES.NOTIFICATION_SCREEN} component={TestScreen} />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({});

export default BottomTabStack;
