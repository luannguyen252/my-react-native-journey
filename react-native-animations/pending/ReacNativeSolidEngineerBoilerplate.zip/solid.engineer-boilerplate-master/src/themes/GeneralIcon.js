const generalIcon = {
  BACK: 'BACK',
  HOME: 'HOME',
  GEOLOCATION: 'GEOLOCATION',
  MARKET: 'MARKET',
  STATISTICS: 'STATISTICS',
  NOTIFICATION: 'NOTIFICATION',
};

export default generalIcon;
