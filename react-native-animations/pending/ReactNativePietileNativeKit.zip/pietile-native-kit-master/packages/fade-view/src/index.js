export { default } from './FadeView';
