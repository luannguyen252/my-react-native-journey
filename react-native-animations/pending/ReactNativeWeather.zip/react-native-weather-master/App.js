import React from 'react';
import Scene from './components/Scene'

export default class App extends React.Component {
    render() {
        return (<Scene />);
    }
}
