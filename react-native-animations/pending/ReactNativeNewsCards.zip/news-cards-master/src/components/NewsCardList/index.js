import NewsCardList from './NewsCardList'
export default NewsCardList 