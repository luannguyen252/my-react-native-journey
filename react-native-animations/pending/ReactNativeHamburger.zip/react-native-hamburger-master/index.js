/* @flow */
'use strict';

import Hamburger from './Hamburger';

export default Hamburger;
