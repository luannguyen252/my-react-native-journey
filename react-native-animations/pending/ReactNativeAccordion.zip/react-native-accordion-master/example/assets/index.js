export const images = {
  whatsapp: require("./whatsapp.png"),
  facebook: require("./facebook.png"),
  instagram: require("./instagram.png"),
};
