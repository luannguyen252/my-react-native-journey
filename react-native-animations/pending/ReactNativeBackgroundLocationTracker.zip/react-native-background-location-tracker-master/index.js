
import { NativeModules } from 'react-native';

const { sajjadBackgroundLocationTracker } = NativeModules;

export default sajjadBackgroundLocationTracker;
