
#if __has_include("RCTBridgeModule.h")
#import "RCTViewManager.h"
#else
#import <React/RCTViewManager.h>
#endif

#import "RCRunkeeperSwitch.h"

@interface RNTextSwitch : RCTViewManager

@end
