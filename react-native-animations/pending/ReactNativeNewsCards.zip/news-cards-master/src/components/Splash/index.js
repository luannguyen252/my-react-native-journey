import Splash from './Splash';
export default Splash;
