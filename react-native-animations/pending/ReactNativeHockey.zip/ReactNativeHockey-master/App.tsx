import React from "react";
import FirstCourse from "./components/FirstCourse";
import SecondCourse from "./components/SecondCourse";
import MyTry from "./components/myTry";
import ThirdCourse from "./components/ThirdCourse";
import MySecondTry from "./components/MySecondTry";
import MyPanTry from "./components/MyPanTry";

export default function App() {
  return <MyPanTry />;
}
