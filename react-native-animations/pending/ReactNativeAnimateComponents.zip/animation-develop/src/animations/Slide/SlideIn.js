import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import DriverShape from '../../drivers/DriverShape';
import Slide from './Slide';

/*
 * SlideIn Component adds slide in effect to its children components.
 * Connect it to driver and pass the input range to animate it.
 * e.g.:
 * ...
 * const driver = new ScrollDriver();
 *
 * return (
 *  <ScrollView
 *    {...driver.scrollViewProps}
 *  >
 *    <SlideIn
 *      driver={driver}
 *      inputRange={[100,150]}
 *      to="top right"
 *    >
 *      <Image />
 *    </SlideIn>
 *  </ScrollView>
 * );
 *
 * ...
 * Above code will create scroll dependent slide in of an Image to
 * the top right corner of the screen between scroll position of 100 and 150
 */
export default class SlideIn extends PureComponent {
  static propTypes = {
    /**
     * An instance of animation driver, usually ScrollDriver
     */
    driver: DriverShape.isRequired,
    /**
     * Components to which an effect will be applied
     */
    children: PropTypes.node.isRequired,
    /**
     * pair of [start, end] values from animation driver, how
     * children would slide in
     */
    inputRange: PropTypes.array,
    /**
     * position from where wrapped components should slide in
     */
    from: PropTypes.string,
    style: PropTypes.object,
  };

  static defaultProps = {
    from: 'top right',
    inputRange: [0, 1],
    style: {},
  };

  render() {
    const { driver, children, inputRange, style, from } = this.props;

    return (
      <Slide
        driver={driver}
        animationName="slideIn"
        inputRange={inputRange}
        direction={from}
        style={style}
      >
        {children}
      </Slide>
    );
  }
}
