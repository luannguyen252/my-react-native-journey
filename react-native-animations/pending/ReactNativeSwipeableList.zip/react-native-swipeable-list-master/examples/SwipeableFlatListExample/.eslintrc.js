module.exports = {
  root: true,
  extends: '@react-native-community',
  rules: {
    'react-native/no-unused-styles': 2,
  },
};
