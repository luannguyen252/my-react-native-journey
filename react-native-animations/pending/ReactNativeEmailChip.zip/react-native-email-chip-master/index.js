import EmailChipInput from './src/EmailChipInput'

export default EmailChipInput;
